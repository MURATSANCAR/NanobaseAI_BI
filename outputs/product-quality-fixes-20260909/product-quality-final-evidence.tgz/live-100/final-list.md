# 100 karmaşık soru — gerçek API/DB doğrulaması

{"LIVE_PASS": 100}

| ID | Soru | Durum | Satır |
|---|---|---|---|
| P09602 | Ocak 2026 için müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında satılan adet göster. | LIVE_PASS | 65379 |
| P09636 | Müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında Şubat 2026 satılan adet hesapla. | LIVE_PASS | 76942 |
| P08802 | Ocak 2024 için müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında satılan adet göster. | LIVE_PASS | 61865 |
| P08808 | Müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında Ocak 2024 perakende satılan adet hesapla. | LIVE_PASS | 10798 |
| P08810 | Ocak 2024 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında satış tutarı nedir? | LIVE_PASS | 61865 |
| P08816 | Ocak 2024 için müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında perakende satış tutarı göster. | LIVE_PASS | 10798 |
| P08818 | Ocak 2024 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında satış satırı sayısı nedir? | LIVE_PASS | 61865 |
| P08824 | Ocak 2024 için müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında perakende satış satırı sayısı göster. | LIVE_PASS | 10798 |
| P08826 | Ocak 2024 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında net satış tutarı nedir? | LIVE_PASS | 68482 |
| P08832 | Ocak 2024 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında perakende net satış tutarı nedir? | LIVE_PASS | 10798 |
| P08840 | Şubat 2024 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında perakende satılan adet nedir? | LIVE_PASS | 9032 |
| P08850 | Müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında Şubat 2024 perakende satış tutarı hesapla. | LIVE_PASS | 9032 |
| P08858 | Müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında Şubat 2024 perakende satış satırı sayısı hesapla. | LIVE_PASS | 9032 |
| P08866 | Şubat 2024 için müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında perakende net satış tutarı göster. | LIVE_PASS | 9194 |
| P08874 | Mart 2024 için müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında perakende satılan adet göster. | LIVE_PASS | 9818 |
| P08882 | Mart 2024 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında perakende satış tutarı nedir? | LIVE_PASS | 9818 |
| P08890 | Mart 2024 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında perakende satış satırı sayısı nedir? | LIVE_PASS | 9818 |
| P08900 | Müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında Mart 2024 perakende net satış tutarı hesapla. | LIVE_PASS | 9996 |
| P08908 | Müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında Nisan 2024 perakende satılan adet hesapla. | LIVE_PASS | 7089 |
| P08916 | Nisan 2024 için müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında perakende satış tutarı göster. | LIVE_PASS | 7089 |
| P08924 | Nisan 2024 için müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında perakende satış satırı sayısı göster. | LIVE_PASS | 7089 |
| P08932 | Nisan 2024 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında perakende net satış tutarı nedir? | LIVE_PASS | 7238 |
| P08940 | Mayıs 2024 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında perakende satılan adet nedir? | LIVE_PASS | 11718 |
| P08950 | Müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında Mayıs 2024 perakende satış tutarı hesapla. | LIVE_PASS | 11718 |
| P08958 | Müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında Mayıs 2024 perakende satış satırı sayısı hesapla. | LIVE_PASS | 11718 |
| P08966 | Mayıs 2024 için müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında perakende net satış tutarı göster. | LIVE_PASS | 11770 |
| P08974 | Haziran 2024 için müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında perakende satılan adet göster. | LIVE_PASS | 14260 |
| P08982 | Haziran 2024 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında perakende satış tutarı nedir? | LIVE_PASS | 14260 |
| P08990 | Haziran 2024 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında perakende satış satırı sayısı nedir? | LIVE_PASS | 14260 |
| P09000 | Müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında Haziran 2024 perakende net satış tutarı hesapla. | LIVE_PASS | 14260 |
| P09008 | Müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında Temmuz 2024 perakende satılan adet hesapla. | LIVE_PASS | 13982 |
| P09016 | Temmuz 2024 için müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında perakende satış tutarı göster. | LIVE_PASS | 13982 |
| P09024 | Temmuz 2024 için müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında perakende satış satırı sayısı göster. | LIVE_PASS | 13982 |
| P09032 | Temmuz 2024 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında perakende net satış tutarı nedir? | LIVE_PASS | 14056 |
| P09040 | Ağustos 2024 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında perakende satılan adet nedir? | LIVE_PASS | 10582 |
| P09050 | Müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında Ağustos 2024 perakende satış tutarı hesapla. | LIVE_PASS | 10582 |
| P09058 | Müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında Ağustos 2024 perakende satış satırı sayısı hesapla. | LIVE_PASS | 10582 |
| P09066 | Ağustos 2024 için müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında perakende net satış tutarı göster. | LIVE_PASS | 10893 |
| P09204 | Ocak 2025 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında toptan satılan adet nedir? | LIVE_PASS | 49663 |
| P09214 | Müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında Ocak 2025 toptan satış tutarı hesapla. | LIVE_PASS | 49663 |
| P09222 | Müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında Ocak 2025 toptan satış satırı sayısı hesapla. | LIVE_PASS | 49663 |
| P09230 | Ocak 2025 için müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında toptan net satış tutarı göster. | LIVE_PASS | 54703 |
| P09238 | Şubat 2025 için müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında toptan satılan adet göster. | LIVE_PASS | 58664 |
| P09246 | Şubat 2025 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında toptan satış tutarı nedir? | LIVE_PASS | 58664 |
| P09254 | Şubat 2025 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında toptan satış satırı sayısı nedir? | LIVE_PASS | 58664 |
| P09264 | Müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında Şubat 2025 toptan net satış tutarı hesapla. | LIVE_PASS | 64438 |
| P09272 | Müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında Mart 2025 toptan satılan adet hesapla. | LIVE_PASS | 45666 |
| P09280 | Mart 2025 için müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında toptan satış tutarı göster. | LIVE_PASS | 45666 |
| P09288 | Mart 2025 için müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında toptan satış satırı sayısı göster. | LIVE_PASS | 45666 |
| P09296 | Mart 2025 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında toptan net satış tutarı nedir? | LIVE_PASS | 52275 |
| P09304 | Nisan 2025 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında toptan satılan adet nedir? | LIVE_PASS | 59299 |
| P09314 | Müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında Nisan 2025 toptan satış tutarı hesapla. | LIVE_PASS | 59299 |
| P09322 | Müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında Nisan 2025 toptan satış satırı sayısı hesapla. | LIVE_PASS | 59299 |
| P09330 | Nisan 2025 için müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında toptan net satış tutarı göster. | LIVE_PASS | 67217 |
| P09338 | Mayıs 2025 için müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında toptan satılan adet göster. | LIVE_PASS | 46953 |
| P09346 | Mayıs 2025 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında toptan satış tutarı nedir? | LIVE_PASS | 46953 |
| P09354 | Mayıs 2025 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında toptan satış satırı sayısı nedir? | LIVE_PASS | 46953 |
| P09364 | Müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında Mayıs 2025 toptan net satış tutarı hesapla. | LIVE_PASS | 59386 |
| P09372 | Müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında Haziran 2025 toptan satılan adet hesapla. | LIVE_PASS | 41626 |
| P09380 | Haziran 2025 için müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında toptan satış tutarı göster. | LIVE_PASS | 41626 |
| P09388 | Haziran 2025 için müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında toptan satış satırı sayısı göster. | LIVE_PASS | 41626 |
| P09396 | Haziran 2025 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında toptan net satış tutarı nedir? | LIVE_PASS | 51357 |
| P09404 | Temmuz 2025 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında toptan satılan adet nedir? | LIVE_PASS | 36520 |
| P09414 | Müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında Temmuz 2025 toptan satış tutarı hesapla. | LIVE_PASS | 36520 |
| P09422 | Müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında Temmuz 2025 toptan satış satırı sayısı hesapla. | LIVE_PASS | 36520 |
| P09430 | Temmuz 2025 için müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında toptan net satış tutarı göster. | LIVE_PASS | 44579 |
| P09438 | Ağustos 2025 için müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında toptan satılan adet göster. | LIVE_PASS | 46627 |
| P09446 | Ağustos 2025 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında toptan satış tutarı nedir? | LIVE_PASS | 46627 |
| P09454 | Ağustos 2025 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında toptan satış satırı sayısı nedir? | LIVE_PASS | 46627 |
| P09464 | Müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında Ağustos 2025 toptan net satış tutarı hesapla. | LIVE_PASS | 49949 |
| P09610 | Ocak 2026 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında satış tutarı nedir? | LIVE_PASS | 65379 |
| P09618 | Ocak 2026 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında satış satırı sayısı nedir? | LIVE_PASS | 65379 |
| P09626 | Ocak 2026 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında net satış tutarı nedir? | LIVE_PASS | 72462 |
| P09644 | Şubat 2026 için müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında satış tutarı göster. | LIVE_PASS | 76942 |
| P09652 | Şubat 2026 için müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında satış satırı sayısı göster. | LIVE_PASS | 76942 |
| P09660 | Şubat 2026 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında net satış tutarı nedir? | LIVE_PASS | 83587 |
| P09668 | Mart 2026 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında satılan adet nedir? | LIVE_PASS | 65781 |
| P09676 | Mart 2026 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında satış tutarı nedir? | LIVE_PASS | 65781 |
| P09686 | Müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında Mart 2026 satış satırı sayısı hesapla. | LIVE_PASS | 65781 |
| P09694 | Mart 2026 için müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında net satış tutarı göster. | LIVE_PASS | 70508 |
| P09702 | Nisan 2026 için müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında satılan adet göster. | LIVE_PASS | 77503 |
| P09710 | Nisan 2026 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında satış tutarı nedir? | LIVE_PASS | 77503 |
| P09718 | Nisan 2026 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında satış satırı sayısı nedir? | LIVE_PASS | 77503 |
| P09726 | Nisan 2026 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında net satış tutarı nedir? | LIVE_PASS | 85703 |
| P09736 | Müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında Mayıs 2026 satılan adet hesapla. | LIVE_PASS | 56042 |
| P09744 | Mayıs 2026 için müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında satış tutarı göster. | LIVE_PASS | 56042 |
| P09752 | Mayıs 2026 için müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında satış satırı sayısı göster. | LIVE_PASS | 56042 |
| P09760 | Mayıs 2026 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında net satış tutarı nedir? | LIVE_PASS | 66980 |
| P09768 | Haziran 2026 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında satılan adet nedir? | LIVE_PASS | 66128 |
| P09776 | Haziran 2026 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında satış tutarı nedir? | LIVE_PASS | 66128 |
| P09786 | Müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında Haziran 2026 satış satırı sayısı hesapla. | LIVE_PASS | 66128 |
| P09794 | Haziran 2026 için müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında net satış tutarı göster. | LIVE_PASS | 81502 |
| P09802 | Temmuz 2026 için müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında satılan adet göster. | LIVE_PASS | 56842 |
| P09810 | Temmuz 2026 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında satış tutarı nedir? | LIVE_PASS | 56842 |
| P09818 | Temmuz 2026 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında satış satırı sayısı nedir? | LIVE_PASS | 56842 |
| P09826 | Temmuz 2026 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında net satış tutarı nedir? | LIVE_PASS | 62816 |
| P09836 | Müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında Ağustos 2026 satılan adet hesapla. | LIVE_PASS | 38263 |
| P09844 | Ağustos 2026 için müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında satış tutarı göster. | LIVE_PASS | 38263 |
| P09852 | Ağustos 2026 için müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında satış satırı sayısı göster. | LIVE_PASS | 38263 |
| P09860 | Ağustos 2026 müşteri, ürün, ödeme planı, satış temsilcisi, teslimat şehri ve birim bazında net satış tutarı nedir? | LIVE_PASS | 38852 |
